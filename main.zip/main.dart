// main.dart – Minimal yet complete Flutter app to track income/expense
// and download YouTube video/audio locally.
// Packages needed (add to pubspec.yaml):
//   flutter:
//     sdk: flutter
//   hive: ^2.0.0
//   hive_flutter: ^1.1.0
//   path_provider: ^2.0.0
//   youtube_explode_dart: ^2.0.3
//   file_picker: ^6.0.0
//   open_filex: ^4.3.2
//   intl: ^0.19.0
//   provider: ^6.1.2  // for simple state management
//
// Run `flutter pub add <package>` for each.
// After cloning this single-file POC into a proper Flutter project,
// add Hive type adapters in a separate file or with build_runner.

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import 'package:file_picker/file_picker.dart';
import 'package:open_filex/open_filex.dart';

part 'main.g.dart'; // for Hive adapter – create via build_runner later

@HiveType(typeId: 0)
class TransactionItem extends HiveObject {
  @HiveField(0)
  double amount;
  @HiveField(1)
  bool isIncome; // true = Income, false = Expense
  @HiveField(2)
  DateTime date;
  @HiveField(3)
  String note;

  TransactionItem({
    required this.amount,
    required this.isIncome,
    required this.date,
    this.note = '',
  });
}

class TransactionProvider extends ChangeNotifier {
  late Box<TransactionItem> _box;
  List<TransactionItem> get items => _box.values.toList();

  Future<void> init() async {
    _box = await Hive.openBox<TransactionItem>('transactions');
    notifyListeners();
  }

  Future<void> add(TransactionItem item) async {
    await _box.add(item);
    notifyListeners();
  }

  double get totalIncome => _box.values
      .where((e) => e.isIncome)
      .fold(0.0, (a, b) => a + b.amount);
  double get totalExpense => _box.values
      .where((e) => !e.isIncome)
      .fold(0.0, (a, b) => a + b.amount);
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final dir = await getApplicationDocumentsDirectory();
  await Hive.initFlutter(dir.path);
  Hive.registerAdapter(TransactionItemAdapter());

  final tp = TransactionProvider();
  await tp.init();

  runApp(ChangeNotifierProvider(
    create: (_) => tp,
    child: const MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'আয়-ব্যয় & YT ডাউনলোডার',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('ড্যাশবোর্ড')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(minimumSize: const Size(220, 48)),
              icon: const Icon(Icons.account_balance_wallet_outlined),
              label: const Text('আয়-ব্যয় হিসাব'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TransactionPage()),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(minimumSize: const Size(220, 48)),
              icon: const Icon(Icons.download_for_offline_outlined),
              label: const Text('YouTube ডাউনলোডার'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const YTDownloaderPage()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TransactionPage extends StatelessWidget {
  const TransactionPage({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TransactionProvider>();
    final format = DateFormat('dd MMM yyyy');
    return Scaffold(
      appBar: AppBar(
        title: const Text('আয়-ব্যয় হিসাব'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(48),
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Chip(
                  label: Text('মোট আয়: ${provider.totalIncome.toStringAsFixed(0)}৳'),
                  avatar: const Icon(Icons.trending_up, color: Colors.green),
                ),
                Chip(
                  label: Text('মোট ব্যয়: ${provider.totalExpense.toStringAsFixed(0)}৳'),
                  avatar: const Icon(Icons.trending_down, color: Colors.red),
                ),
              ],
            ),
          ),
        ),
      ),
      body: ValueListenableBuilder(
        valueListenable: Hive.box<TransactionItem>('transactions').listenable(),
        builder: (context, Box<TransactionItem> box, _) {
          if (box.isEmpty) {
            return const Center(child: Text('কোনো ডাটা নেই। + দিয়ে যুক্ত করুন।'));
          }
          return ListView.builder(
            itemCount: box.length,
            itemBuilder: (_, i) {
              final item = box.getAt(i)!;
              return ListTile(
                leading: Icon(
                  item.isIncome ? Icons.add_circle : Icons.remove_circle,
                  color: item.isIncome ? Colors.green : Colors.red,
                ),
                title: Text('${item.amount.toStringAsFixed(0)}৳'),
                subtitle: Text('${item.note} • ${format.format(item.date)}'),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () => showDialog(
          context: context,
          builder: (_) => const AddTransactionDialog(),
        ),
      ),
    );
  }
}

class AddTransactionDialog extends StatefulWidget {
  const AddTransactionDialog({super.key});

  @override
  State<AddTransactionDialog> createState() => _AddTransactionDialogState();
}

class _AddTransactionDialogState extends State<AddTransactionDialog> {
  final _formKey = GlobalKey<FormState>();
  final _amountController = TextEditingController();
  final _noteController = TextEditingController();
  bool _isIncome = false;
  DateTime _selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('নতুন ইনপুট যুক্ত করুন'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                title: Text(_isIncome ? 'আয়' : 'ব্যয়'),
                secondary: Icon(_isIncome ? Icons.trending_up : Icons.trending_down),
                value: _isIncome,
                onChanged: (v) => setState(() => _isIncome = v),
              ),
              TextFormField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'এমাউন্ট (৳)'),
                validator: (v) => v == null || v.isEmpty ? 'এমাউন্ট দিন' : null,
              ),
              TextFormField(
                controller: _noteController,
                decoration: const InputDecoration(labelText: 'নোট (ঐচ্ছিক)'),
              ),
              Row(
                children: [
                  Text(DateFormat('dd MMM yyyy').format(_selectedDate)),
                  IconButton(
                    icon: const Icon(Icons.calendar_today),
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: _selectedDate,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) {
                        setState(() => _selectedDate = picked);
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('বাতিল'),
        ),
        ElevatedButton(
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              final provider = context.read<TransactionProvider>();
              provider.add(TransactionItem(
                amount: double.parse(_amountController.text),
                isIncome: _isIncome,
                date: _selectedDate,
                note: _noteController.text,
              ));
              Navigator.pop(context);
            }
          },
          child: const Text('সংরক্ষণ'),
        ),
      ],
    );
  }
}

class YTDownloaderPage extends StatefulWidget {
  const YTDownloaderPage({super.key});

  @override
  State<YTDownloaderPage> createState() => _YTDownloaderPageState();
}

class _YTDownloaderPageState extends State<YTDownloaderPage> {
  final _urlController = TextEditingController();
  bool _isDownloading = false;
  double _progress = 0.0;

  Future<void> _download({required bool audioOnly}) async {
    final url = _urlController.text.trim();
    if (url.isEmpty) return;

    setState(() {
      _isDownloading = true;
      _progress = 0.0;
    });

    final yt = YoutubeExplode();
    try {
      final video = await yt.videos.get(Uri.parse(url));
      final manifest = await yt.videos.streamsClient.getManifest(video.id);
      final streamInfo = audioOnly
          ? manifest.audioOnly.withHighestBitrate()
          : manifest.muxed.withHighestBitrate();

      final dir = await getExternalStorageDirectory();
      final fileName =
          "${video.title.replaceAll(RegExp(r'[\\/:*?"<>|]'), '')}.${audioOnly ? 'mp3' : 'mp4'}";
      final filePath = "${dir!.path}/$fileName";
      final file = File(filePath);
      final stream = yt.videos.streamsClient.get(streamInfo);
      final output = file.openWrite();
      final len = streamInfo.size.totalBytes;
      var count = 0;

      await for (final data in stream) {
        count += data.length;
        output.add(data);
        setState(() => _progress = count / len);
      }
      await output.close();

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('সম্পন্ন! $fileName সংরক্ষিত হয়েছে')),
        );
        OpenFilex.open(filePath);
      }
    } catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('ত্রুটি: $e')));
    } finally {
      yt.close();
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('YouTube ডাউনলোডার')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _urlController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'YouTube URL',
              ),
            ),
            const SizedBox(height: 16),
            if (_isDownloading)
              LinearProgressIndicator(value: _progress)
            else
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.download),
                    label: const Text('ভিডিও'),
                    onPressed: () => _download(audioOnly: false),
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.music_note),
                    label: const Text('অডিও'),
                    onPressed: () => _download(audioOnly: true),
                  ),
                ],
              ),
            const SizedBox(height: 16),
            const Text(
              'বি.দ্র.: YouTube এর Terms of Service অনুযায়ী, কিছু সামগ্রী ডাউনলোড করা সীমাবদ্ধ হতে পারে। দয়া করে কপিরাইট আইন মেনে চলুন।',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
